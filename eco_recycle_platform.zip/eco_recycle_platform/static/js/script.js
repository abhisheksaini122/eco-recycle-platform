// Initialize tooltips and popovers
document.addEventListener('DOMContentLoaded', function() {
    // Bootstrap tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Add animations
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.boxShadow = '0 1px 3px rgba(0,0,0,0.1)';
        });
    });
});

// Form validation
function validateForm(formId) {
    const form = document.getElementById(formId);
    if (form && !form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
    }
    form.classList.add('was-validated');
}

// Confirm before delete
function confirmDelete(message = 'Are you sure?') {
    return confirm(message || 'Are you sure you want to proceed?');
}

// Send AJAX message
async function sendMessage(userId, message) {
    try {
        const response = await fetch(`/chat/${userId}/send`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ message: message })
        });
        
        const data = await response.json();
        if (data.status === 'success') {
            console.log('Message sent successfully - script.js:49');
            return true;
        } else {
            console.error('Error: - script.js:52', data.error);
            return false;
        }
    } catch (error) {
        console.error('Error: - script.js:56', error);
        return false;
    }
}

// Update eco points display
function updateEcoPoints(newPoints) {
    const display = document.getElementById('eco-points-display');
    if (display) {
        display.innerHTML = `<strong>${newPoints}</strong> <i class="bi bi-star-fill"></i>`;
    }
}

// Toggle dark mode
function toggleDarkMode() {
    const html = document.documentElement;
    const isDarkMode = html.getAttribute('data-bs-theme') === 'dark';
    
    if (isDarkMode) {
        html.removeAttribute('data-bs-theme');
        localStorage.setItem('theme', 'light');
    } else {
        html.setAttribute('data-bs-theme', 'dark');
        localStorage.setItem('theme', 'dark');
    }
}

// Load saved theme
function loadTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
        document.documentElement.setAttribute('data-bs-theme', 'dark');
    }
}

// Initialize on load
window.addEventListener('load', loadTheme);
