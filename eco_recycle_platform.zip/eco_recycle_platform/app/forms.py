from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SelectField, SubmitField, FileField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError, Length
from wtforms.widgets import TextArea

class RegistrationForm(FlaskForm):
    """User registration form"""
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('Confirm Password', 
                                     validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    """User login form"""
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class AddProductForm(FlaskForm):
    """Form to add a new product for recycling"""
    name = StringField('Product Name', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    category = SelectField('Category', choices=[
        ('Electronics', 'Electronics'),
        ('Textiles', 'Textiles'),
        ('Plastic', 'Plastic'),
        ('Metal', 'Metal'),
        ('Glass', 'Glass'),
        ('Paper', 'Paper'),
        ('Organic', 'Organic'),
        ('Other', 'Other')
    ], validators=[DataRequired()])
    condition = SelectField('Condition', choices=[
        ('Excellent', 'Excellent'),
        ('Good', 'Good'),
        ('Fair', 'Fair'),
        ('Needs Repair', 'Needs Repair')
    ], default='Good')
    image = FileField('Product Image')
    submit = SubmitField('Add Product')

class ChatForm(FlaskForm):
    """Direct messaging form"""
    message = TextAreaField('Message', validators=[DataRequired(), Length(min=1, max=1000)])
    submit = SubmitField('Send')

class ProfileForm(FlaskForm):
    """User profile update form"""
    username = StringField('Username', validators=[DataRequired()])
    bio = TextAreaField('Bio')
    profile_image = FileField('Profile Image')
    submit = SubmitField('Update Profile')

class TransactionForm(FlaskForm):
    """Transaction/exchange form"""
    recipient = StringField('Recipient Username', validators=[DataRequired()])
    notes = TextAreaField('Exchange Notes')
    submit = SubmitField('Complete Exchange')
