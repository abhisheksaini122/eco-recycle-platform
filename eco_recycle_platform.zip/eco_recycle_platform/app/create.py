from flask import Flask
from config import DevelopmentConfig
from app.extensions import db, login_manager
import os

def create_app():
    print("CWD: - create.py:7", os.getcwd())
    print("Template exists: - create.py:8", os.path.exists('app/templates/index.html'))

    app = Flask(__name__, template_folder='app/templates', static_folder='app/static')
    app.config.from_object(DevelopmentConfig)
    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'
    with app.app_context():
        from app.models import User, Product, Transaction, Chat, Notification, Badge, Analytics
        db.create_all()
        from app.routes import register_routes
        register_routes(app)
    return app
