from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

from app.models import User, Product, Transaction, Chat, Notification, Badge, Analytics
from app.extensions import db

def register_routes(app):

    @app.route('/')
    def index():
        products_count = Product.query.count()
        users_count = User.query.count()
        transactions_count = Transaction.query.count()
        return render_template('index.html',
                              products_count=products_count,
                              users_count=users_count,
                              transactions_count=transactions_count)

    @app.route('/register', methods=['GET', 'POST'])
    def register():
        from app.forms import RegistrationForm
        form = RegistrationForm()
        if form.validate_on_submit():
            if User.query.filter_by(email=form.email.data).first():
                flash('Email already exists!', 'danger')
                return redirect(url_for('register'))
            user = User(
                username=form.username.data,
                email=form.email.data,
                password_hash=generate_password_hash(form.password.data),
                eco_points=0,
                badge_level='Beginner'
            )
            db.session.add(user)
            db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        return render_template('register.html', form=form)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        from app.forms import LoginForm
        form = LoginForm()
        if form.validate_on_submit():
            user = User.query.filter_by(email=form.email.data).first()
            if user and check_password_hash(user.password_hash, form.password.data):
                login_user(user)
                flash('Logged in successfully!', 'success')
                return redirect(url_for('dashboard'))
            else:
                flash('Invalid email or password!', 'danger')
        return render_template('login.html', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        flash('Logged out successfully!', 'success')
        return redirect(url_for('index'))

    @app.route('/dashboard')
    @login_required
    def dashboard():
        user_products = Product.query.filter_by(owner_id=current_user.id).all()
        recent_transactions = Transaction.query.filter_by(user_id=current_user.id).limit(5).all()
        unread_chats = Chat.query.filter_by(recipient_id=current_user.id, is_read=False).count()
        unread_notifications = Notification.query.filter_by(user_id=current_user.id, is_read=False).count()
        return render_template('dashboard.html',
                              user_products=user_products,
                              recent_transactions=recent_transactions,
                              unread_chats=unread_chats,
                              unread_notifications=unread_notifications)

    @app.route('/products')
    def products():
        page = request.args.get('page', 1, type=int)
        products = Product.query.filter_by(is_available=True).paginate(page=page, per_page=12)
        return render_template('product_list.html', products=products)

    @app.route('/product/add', methods=['GET', 'POST'])
    @login_required
    def add_product():
        from app.forms import AddProductForm
        form = AddProductForm()
        if form.validate_on_submit():
            product = Product(
                name=form.name.data,
                description=form.description.data,
                category=form.category.data,
                condition=form.condition.data,
                owner_id=current_user.id,
                eco_value=20 if form.condition.data == 'Excellent' else 15
            )
            db.session.add(product)
            db.session.commit()
            flash('Product added successfully!', 'success')
            return redirect(url_for('products'))
        return render_template('product_add.html', form=form)

    @app.route('/product/<int:product_id>')
    def view_product(product_id):
        product = Product.query.get_or_404(product_id)
        return render_template('product_detail.html', product=product)

    @app.route('/transactions')
    @login_required
    def transactions():
        page = request.args.get('page', 1, type=int)
        user_transactions = Transaction.query.filter_by(user_id=current_user.id).paginate(page=page, per_page=10)
        return render_template('transaction_history.html', transactions=user_transactions)

    @app.route('/exchange/<int:product_id>', methods=['POST'])
    @login_required
    def exchange_product(product_id):
        product = Product.query.get_or_404(product_id)
        if product.owner_id == current_user.id:
            flash('You cannot exchange your own product!', 'danger')
            return redirect(url_for('view_product', product_id=product_id))
        transaction = Transaction(
            product_id=product_id,
            user_id=current_user.id,
            recipient_id=product.owner_id,
            eco_points_earned=product.eco_value,
            transaction_type='Exchange',
            status='Completed',
            transaction_icon='exchange'
        )
        current_user.eco_points += product.eco_value
        current_user.total_items_recycled += 1
        if current_user.eco_points >= 500:
            current_user.badge_level = 'Eco Champion'
        elif current_user.eco_points >= 300:
            current_user.badge_level = 'Eco Warrior'
        elif current_user.eco_points >= 100:
            current_user.badge_level = 'Eco Advocate'
        product.is_available = False
        db.session.add(transaction)
        db.session.commit()
        flash('Exchange completed! Eco points earned: ' + str(product.eco_value), 'success')
        return redirect(url_for('transactions'))

    @app.route('/leaderboard')
    def leaderboard():
        users = User.query.order_by(User.eco_points.desc()).limit(50).all()
        return render_template('leaderboard.html', users=users)

    @app.route('/profile/<username>')
    def profile(username):
        user = User.query.filter_by(username=username).first_or_404()
        user_products = Product.query.filter_by(owner_id=user.id, is_available=True).all()
        return render_template('profile.html', user=user, products=user_products)

    @app.route('/profile/edit', methods=['GET', 'POST'])
    @login_required
    def edit_profile():
        from app.forms import ProfileForm
        form = ProfileForm()
        if form.validate_on_submit():
            current_user.username = form.username.data
            current_user.bio = form.bio.data
            db.session.commit()
            flash('Profile updated successfully!', 'success')
            return redirect(url_for('profile', username=current_user.username))
        form.username.data = current_user.username
        form.bio.data = current_user.bio
        return render_template('edit_profile.html', form=form)

    @app.route('/chat/<int:user_id>')
    @login_required
    def chat(user_id):
        recipient = User.query.get_or_404(user_id)
        messages = Chat.query.filter(
            ((Chat.sender_id == current_user.id) & (Chat.recipient_id == user_id)) |
            ((Chat.sender_id == user_id) & (Chat.recipient_id == current_user.id))
        ).order_by(Chat.created_at).all()
        Chat.query.filter_by(recipient_id=current_user.id, sender_id=user_id, is_read=False).update({'is_read': True})
        db.session.commit()
        return render_template('chat.html', recipient=recipient, messages=messages)

    @app.route('/chat/<int:user_id>/send', methods=['POST'])
    @login_required
    def send_message(user_id):
        data = request.get_json()
        message = data.get('message')
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400
        chat = Chat(
            sender_id=current_user.id,
            recipient_id=user_id,
            message=message
        )
        db.session.add(chat)
        db.session.commit()
        return jsonify({'status': 'success', 'message_id': chat.id})

    @app.route('/analytics')
    @login_required
    def analytics():
        user_transactions = Transaction.query.filter_by(user_id=current_user.id).all()
        total_eco_points = sum(t.eco_points_earned for t in user_transactions)
        co2_saved = total_eco_points * 0.5
        items_recycled = len(user_transactions)
        return render_template('analytics.html',
                              eco_points=total_eco_points,
                              co2_saved=co2_saved,
                              items_recycled=items_recycled)

    @app.route('/notifications')
    @login_required
    def notifications():
        page = request.args.get('page', 1, type=int)
        notifications = Notification.query.filter_by(user_id=current_user.id).paginate(page=page, per_page=10)
        Notification.query.filter_by(user_id=current_user.id, is_read=False).update({'is_read': True})
        db.session.commit()
        return render_template('notifications.html', notifications=notifications)

    @app.route('/admin/users')
    @login_required
    def admin_users():
        users = User.query.all()
        return render_template('admin_users.html', users=users)

    @app.route('/admin/analytics')
    @login_required
    def admin_analytics():
        users_count = User.query.count()
        products_count = Product.query.count()
        transactions_count = Transaction.query.count()
        total_eco_points = db.session.query(db.func.sum(User.eco_points)).scalar() or 0
        return render_template('admin_analytics.html',
                              users_count=users_count,
                              products_count=products_count,
                              transactions_count=transactions_count,
                              total_eco_points=total_eco_points)

    @app.errorhandler(404)
    def not_found(error):
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def server_error(error):
        return render_template('500.html'), 500
