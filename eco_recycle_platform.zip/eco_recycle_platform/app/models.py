from app.extensions import db
from datetime import datetime

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    eco_points = db.Column(db.Integer, default=0)
    total_items_recycled = db.Column(db.Integer, default=0)
    bio = db.Column(db.Text, default='')
    profile_image = db.Column(db.String(255), default='default.png')
    badge_level = db.Column(db.String(50), default='Beginner')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)

    products = db.relationship('Product', backref='owner', lazy=True, cascade='all, delete-orphan')
    transactions = db.relationship('Transaction', backref='user', lazy=True, cascade='all, delete-orphan', foreign_keys='Transaction.user_id')
    chats_sent = db.relationship('Chat', backref='sender', lazy=True, foreign_keys='Chat.sender_id')
    chats_received = db.relationship('Chat', backref='recipient', lazy=True, foreign_keys='Chat.recipient_id')
    notifications = db.relationship('Notification', backref='user', lazy=True, cascade='all, delete-orphan')

    def get_id(self):
        return str(self.id)
    @property
    def is_authenticated(self):
        return True

class Product(db.Model):
    __tablename__ = 'products'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50), nullable=False)
    condition = db.Column(db.String(50), default='Good')
    eco_value = db.Column(db.Integer, default=10)
    image_url = db.Column(db.String(255))
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    is_available = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    recycling_chain = db.Column(db.String(500), default='')
    rating = db.Column(db.Float, default=5.0)
    rating_count = db.Column(db.Integer, default=0)

    transactions = db.relationship('Transaction', backref='product', lazy=True, cascade='all, delete-orphan')

class Transaction(db.Model):
    __tablename__ = 'transactions'
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('products.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    transaction_type = db.Column(db.String(50), default='Exchange')
    eco_points_earned = db.Column(db.Integer, default=10)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    status = db.Column(db.String(50), default='Completed')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    notes = db.Column(db.Text)
    transaction_icon = db.Column(db.String(50), default='exchange')

class Chat(db.Model):
    __tablename__ = 'chats'
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    recipient_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    __tablename__ = 'notifications'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text)
    notification_type = db.Column(db.String(50), default='Info')
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Badge(db.Model):
    __tablename__ = 'badges'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    icon = db.Column(db.String(100))
    requirement_points = db.Column(db.Integer)

class Analytics(db.Model):
    __tablename__ = 'analytics'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    co2_saved = db.Column(db.Float, default=0.0)
    items_recycled = db.Column(db.Integer, default=0)
    waste_diverted_kg = db.Column(db.Float, default=0.0)
    date = db.Column(db.DateTime, default=datetime.utcnow)
