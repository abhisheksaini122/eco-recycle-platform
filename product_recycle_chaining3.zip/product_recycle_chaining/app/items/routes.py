from flask import Blueprint, render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from app import db
from app.models import Item, Transaction
from werkzeug.utils import secure_filename
from datetime import datetime
import os
from app.utils.i18n import gettext
from app.utils.ai_helper import auto_tag_image
from sqlalchemy import or_

bp = Blueprint('items', __name__)



def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']

@bp.route('/')
def browse():
    page = request.args.get('page', 1, type=int)
    query = Item.query.filter_by(status='available')

    search_query = request.args.get('q', '')
    category = request.args.get('category', '')
    listing_type = request.args.get('type', '')

    if search_query:
        query = query.filter(or_(
            Item.title.ilike(f'%{search_query}%'),
            Item.description.ilike(f'%{search_query}%'),
            Item.auto_tags.ilike(f'%{search_query}%')
        ))

    if category:
        query = query.filter_by(category=category)

    if listing_type:
        query = query.filter_by(listing_type=listing_type)

    items_paginated = query.order_by(Item.created_at.desc()).paginate(
        page=page, per_page=current_app.config['ITEMS_PER_PAGE'], error_out=False
    )
    items = items_paginated.items

    return render_template('items/browse.html',
                          title=gettext('Browse Items'),
                          items=items,
                          items_paginated=items_paginated)

@bp.route('/post', methods=['GET', 'POST'])
@login_required
def post_item():
    if request.method == 'POST':
        item = Item(
            user_id=current_user.id,
            title=request.form.get('title'),
            description=request.form.get('description'),
            category=request.form.get('category'),
            condition=request.form.get('condition'),
            quantity=request.form.get('quantity', 1),
            listing_type=request.form.get('listing_type'),
            exchange_preference=request.form.get('exchange_preference'),
            location=request.form.get('location')
        )

        if 'image' in request.files:
            file = request.files['image']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filename = f"item_{current_user.id}_{datetime.utcnow().timestamp()}.{filename.rsplit('.', 1)[1].lower()}"
                filepath = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                item.image_url = filename

                try:
                    tags = auto_tag_image(filepath)
                    if tags:
                        item.auto_tags = ', '.join(tags)
                except Exception as e:
                    print(f"AI tagging failed: {e} - routes.py:81")

        db.session.add(item)
        db.session.commit()
        current_user.add_eco_points(2)

        flash(gettext('Item posted successfully'), 'success')
        return redirect(url_for('items.item_detail', item_id=item.id))

    return render_template('items/post.html', title=gettext('Post Item'))

@bp.route('/<int:item_id>')
def item_detail(item_id):
    item = Item.query.get_or_404(item_id)
    item.increment_views()

    similar_items = Item.query.filter(Item.category == item.category, Item.id != item.id, Item.status == 'available').limit(4).all()

    return render_template('items/detail.html', title=item.title, item=item, similar_items=similar_items)

@bp.route('/<int:item_id>/request', methods=['POST'])
@login_required
def request_item(item_id):
    item = Item.query.get_or_404(item_id)

    if item.user_id == current_user.id:
        flash(gettext('Cannot request your own item'), 'warning')
        return redirect(url_for('items.item_detail', item_id=item_id))

    transaction = Transaction(item_id=item.id, from_user_id=item.user_id, to_user_id=current_user.id, request_message=request.form.get('message'))

    db.session.add(transaction)
    db.session.commit()

    flash(gettext('Request sent successfully'), 'success')
    return redirect(url_for('items.item_detail', item_id=item_id))

@bp.route('/my-items')
@login_required
def my_items():
    page = request.args.get('page', 1, type=int)
    items = Item.query.filter_by(user_id=current_user.id).order_by(Item.created_at.desc()).paginate(page=page, per_page=12, error_out=False)
    return render_template('items/my_items.html', title=gettext('My Items'), items=items)

@bp.route('/<int:item_id>/delete', methods=['POST'])
@login_required
def delete_item(item_id):
    item = Item.query.get_or_404(item_id)

    if item.user_id != current_user.id and not current_user.is_admin:
        flash(gettext('Unauthorized'), 'danger')
        return redirect(url_for('items.item_detail', item_id=item_id))

    db.session.delete(item)
    db.session.commit()

    flash(gettext('Item deleted successfully'), 'success')
    return redirect(url_for('items.my_items'))

@bp.route('/<int:item_id>/transaction', methods=['GET', 'POST'])
@login_required
def transaction(item_id):
    item = Item.query.get_or_404(item_id)
    
    if request.method == 'POST':
        trx = Transaction(
            item_id=item.id,
            from_user_id=item.user_id,
            to_user_id=current_user.id,
            request_message=request.form.get('message'),
            created_at=datetime.utcnow(),
            status='pending'
        )
        db.session.add(trx)
        db.session.commit()
        
        # Award eco points
        current_user.add_eco_points(1)
        
        flash('Transaction request sent successfully!', 'success')
        return redirect(url_for('items.item_detail', item_id=item_id))
    
    # Get all transactions for this item
    transactions = Transaction.query.filter_by(item_id=item_id).order_by(Transaction.created_at.desc()).all()
    
    return render_template('items/transaction.html', item=item, transactions=transactions)
