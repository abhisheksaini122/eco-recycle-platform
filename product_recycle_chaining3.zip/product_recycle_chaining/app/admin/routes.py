from flask import Blueprint, render_template, redirect, url_for, flash
from flask_login import login_required, current_user
from app.models import User, Item, Transaction
from app import db
from functools import wraps
from app.utils.i18n import gettext

bp = Blueprint('admin', __name__)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash(gettext('Admin access required'), 'danger')
            return redirect(url_for('main.index'))
        return f(*args, **kwargs)
    return decorated_function

@bp.route('/dashboard')
@login_required
@admin_required
def dashboard():
    total_users = User.query.count()
    total_items = Item.query.count()
    pending_transactions = Transaction.query.filter_by(status='pending').count()
    completed_transactions = Transaction.query.filter_by(status='completed').count()

    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    recent_items = Item.query.order_by(Item.created_at.desc()).limit(10).all()

    return render_template('admin/dashboard.html', title=gettext('Admin Dashboard'), total_users=total_users, total_items=total_items, pending_transactions=pending_transactions, completed_transactions=completed_transactions, recent_users=recent_users, recent_items=recent_items)

@bp.route('/users')
@login_required
@admin_required
def manage_users():
    users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin/users.html', title=gettext('Manage Users'), users=users)

@bp.route('/items')
@login_required
@admin_required
def manage_items():
    items = Item.query.order_by(Item.created_at.desc()).all()
    return render_template('admin/items.html', title=gettext('Manage Items'), items=items)

@bp.route('/items/<int:item_id>/feature', methods=['POST'])
@login_required
@admin_required
def toggle_featured(item_id):
    item = Item.query.get_or_404(item_id)
    item.is_featured = not item.is_featured
    db.session.commit()
    flash(gettext('Item featured status updated'), 'success')
    return redirect(url_for('admin.manage_items'))
