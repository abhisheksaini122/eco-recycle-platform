from flask import Blueprint, render_template, request, make_response, redirect, url_for, session
from app.models import Item, User, Transaction
from app import db
from sqlalchemy import func, desc
from app.utils.i18n import LANGUAGES, gettext, get_locale
from flask_login import current_user

bp = Blueprint('main', __name__)

@bp.route('/')
@bp.route('/index')
def index():
    featured_items = Item.query.filter_by(status='available', is_featured=True).limit(8).all()
    if not featured_items:
        featured_items = Item.query.filter_by(status='available').order_by(Item.created_at.desc()).limit(8).all()

    total_items = Item.query.count()
    total_users = User.query.count()
    completed_transactions = Transaction.query.filter_by(status='completed').count()

    category_stats = db.session.query(Item.category, func.count(Item.id).label('count')).filter_by(status='available').group_by(Item.category).all()

    return render_template('index.html', title=gettext('Home'), featured_items=featured_items, total_items=total_items, total_users=total_users, completed_transactions=completed_transactions, category_stats=category_stats, LANGUAGES=LANGUAGES, get_locale=get_locale)


@bp.route('/set_lang/<lang_code>')
def set_lang(lang_code):
    resp = make_response(redirect(request.referrer or url_for('main.index')))
    if lang_code in LANGUAGES:
        resp.set_cookie('lang', lang_code, max_age=60*60*24*365)
        session['language'] = lang_code
        if current_user.is_authenticated:
            current_user.preferred_language = lang_code
            db.session.commit()
    return resp


@bp.route('/about')
def about():
    return render_template('about.html', title=gettext('About Us'))

@bp.route('/leaderboard')
def leaderboard():
    top_users = User.query.order_by(User.eco_points.desc()).limit(10).all()
    return render_template('main/leaderboard.html', users=top_users)

@bp.route('/categories')
def categories():
    category_list = [
        {'name': 'Electronics', 'icon': 'fas fa-laptop-code', 'description': gettext('Electronics and gadgets')},
        {'name': 'Furniture', 'icon': 'fas fa-couch', 'description': gettext('Furniture, Home and Office')},
        {'name': 'Clothing', 'icon': 'fas fa-tshirt', 'description': gettext('Clothing & Accessories')},
        {'name': 'Books', 'icon': 'fas fa-book', 'description': gettext('Books & Stationery')},
        {'name': 'Toys', 'icon': 'fas fa-puzzle-piece', 'description': gettext('Toys for Kids')},
        {'name': 'Appliances', 'icon': 'fas fa-blender', 'description': gettext('Home Appliances')},
        {'name': 'Sports', 'icon': 'fas fa-futbol', 'description': gettext('Sports & Outdoors')},
        {'name': 'Tools', 'icon': 'fas fa-tools', 'description': gettext('Tools and Hardware')},
        {'name': 'Kitchenware', 'icon': 'fas fa-utensils', 'description': gettext('Kitchen Items')},
        {'name': 'Decor', 'icon': 'fas fa-paint-brush', 'description': gettext('Decor & Arts')},
        {'name': 'Other', 'icon': 'fas fa-box', 'description': gettext('Other')}
    ]
    return render_template('categories.html', title=gettext('Categories'), categories=category_list)




