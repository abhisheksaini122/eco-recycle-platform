from flask import Flask, request, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from flask_mail import Mail
from config import config
import os

db = SQLAlchemy()
login_manager = LoginManager()
bcrypt = Bcrypt()
migrate = Migrate()
mail = Mail()

def create_app(config_name='default'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])

    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)
    bcrypt.init_app(app)
    migrate.init_app(app, db)
    mail.init_app(app)

    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'

    # ===== THIS BLOCK IS MOST IMPORTANT =====
    from app.utils.i18n import gettext, get_locale
    app.jinja_env.globals['gettext'] = gettext
    app.jinja_env.globals['LANGUAGES'] = app.config['LANGUAGES']
    app.jinja_env.globals['get_locale'] = get_locale
    # ========================================

    from app.main import routes as main_routes
    from app.auth import routes as auth_routes
    from app.items import routes as item_routes
    from app.admin import routes as admin_routes
    from app.api import routes as api_routes

    # ===== DO NOT PUT extra code/comments in url_prefix!! =====
    app.register_blueprint(main_routes.bp)
    app.register_blueprint(auth_routes.bp, url_prefix='/auth - __init__.py:47')
    app.register_blueprint(item_routes.bp, url_prefix='/items - __init__.py:48')
    app.register_blueprint(admin_routes.bp, url_prefix='/admin - __init__.py:49')
    app.register_blueprint(api_routes.bp, url_prefix='/api - __init__.py:50')
    # ==========================================================

    with app.app_context():
        db.create_all()

    return app

from app import models
