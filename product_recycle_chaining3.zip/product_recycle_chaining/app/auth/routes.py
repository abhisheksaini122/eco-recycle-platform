from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from flask_login import login_user, logout_user, current_user, login_required
from app import db, bcrypt
from app.models import User
from datetime import datetime
from app.utils.i18n import gettext

bp = Blueprint('auth', __name__)

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        phone = request.form.get('phone')
        city = request.form.get('city')
        language = request.form.get('language', 'en')

        if User.query.filter_by(email=email).first():
            flash(gettext('Email already registered'), 'danger')
            return redirect(url_for('auth.register'))

        if User.query.filter_by(username=username).first():
            flash(gettext('Username already taken'), 'danger')
            return redirect(url_for('auth.register'))

        user = User(username=username, email=email.lower(), phone=phone, city=city, preferred_language=language)
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        flash(gettext('Registration successful! Please login.'), 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html', title=gettext('Register'))

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.index'))

    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = request.form.get('remember') == 'on'

        user = User.query.filter_by(email=email.lower()).first()

        if user and user.check_password(password):
            login_user(user, remember=remember)
            user.last_login = datetime.utcnow()
            db.session.commit()

            if user.preferred_language:
                session['language'] = user.preferred_language

            next_page = request.args.get('next')
            flash(gettext('Welcome back') + f', {user.username}!', 'success')
            return redirect(next_page) if next_page else redirect(url_for('main.index'))
        else:
            flash(gettext('Invalid email or password'), 'danger')

    return render_template('auth/login.html', title=gettext('Login'))

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash(gettext('You have been logged out'), 'info')
    return redirect(url_for('main.index'))

@bp.route('/profile')
@login_required
def profile():
    return render_template('auth/profile.html', title=gettext('Profile'))

@bp.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        current_user.username = request.form.get('username')
        current_user.phone = request.form.get('phone')
        current_user.address = request.form.get('address')
        current_user.city = request.form.get('city')
        current_user.state = request.form.get('state')
        current_user.pincode = request.form.get('pincode')
        current_user.preferred_language = request.form.get('language', 'en')

        session['language'] = current_user.preferred_language
        db.session.commit()
        flash(gettext('Profile updated successfully'), 'success')
        return redirect(url_for('auth.profile'))

    return render_template('auth/edit_profile.html', title=gettext('Edit Profile'))
