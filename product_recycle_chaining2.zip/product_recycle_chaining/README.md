# Product Recycle Chain Platform 🌍♻️

## Advanced Multi-Language Circular Economy Platform with AI Features

A comprehensive Flask-based web platform enabling resource reuse through donation, exchange, and repurposing. Supports **12 Indian languages** and features **AI-powered image tagging**.

---

## 🚀 Features

### Core Features
- ✅ **Multi-Language Support** - 12 Indian languages
- ✅ **AI-Powered Image Tagging** - Automatic categorization using HuggingFace CLIP
- ✅ **User Authentication** - Secure registration and login
- ✅ **Item Management** - Post, edit, delete, browse with filters
- ✅ **Transaction System** - Request, approve, complete transactions
- ✅ **Eco Points Gamification** - Reward sustainable actions
- ✅ **RESTful API** - JSON endpoints
- ✅ **Admin Dashboard** - User and item moderation
- ✅ **Smart Search** - Search by AI tags, title, description

---

## 📦 Installation

### Windows
```bash
# 1. Extract ZIP file
# 2. Open Command Prompt in folder
# 3. Run:
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
python run.py

# 4. Open browser: http://localhost:5000
```

### Linux/Mac
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python run.py
```

---

## 🌐 Supported Languages

1. English (en)
2. हिन्दी (hi) - Hindi
3. தமிழ் (ta) - Tamil
4. తెలుగు (te) - Telugu
5. বাংলা (bn) - Bengali
6. मराठी (mr) - Marathi
7. ગુજરાતી (gu) - Gujarati
8. اُردُو (ur) - Urdu
9. ಕನ್ನಡ (kn) - Kannada
10. മലയാളം (ml) - Malayalam
11. ଓଡ଼ିଆ (or) - Odia
12. ਪੰਜਾਬੀ (pa) - Punjabi

---

## 🤖 AI Features

### Image Auto-Tagging
- Upload an image when posting an item
- AI automatically generates relevant tags
- Uses HuggingFace CLIP model
- Improves searchability

**To Enable:**
1. Get API key from [HuggingFace](https://huggingface.co/)
2. Set environment variable:
```bash
# Windows
set HUGGINGFACE_API_KEY=your_key_here

# Linux/Mac
export HUGGINGFACE_API_KEY=your_key_here
```

---

## 📁 Project Structure

```
product_recycle_chaining/
│
├── app/
│   ├── __init__.py
│   ├── models.py
│   ├── auth/
│   ├── items/
│   ├── main/
│   ├── admin/
│   ├── api/
│   ├── utils/
│   │   ├── i18n.py
│   │   ├── ai_helper.py
│   │   └── lang/
│   ├── static/uploads/
│   └── templates/
│
├── config.py
├── requirements.txt
├── run.py
└── README.md
```

---

## 🎮 Usage

1. **Register** - Choose your preferred language
2. **Browse Items** - Explore categories
3. **Post Item** - Upload image (AI auto-tags!)
4. **Request Items** - Send message to owner
5. **Earn Eco Points** - Get rewards for contributions

---

## 🔒 Security

- Bcrypt password hashing
- CSRF protection
- SQL injection prevention
- File upload validation
- Session security

---

## 📡 API Endpoints

- `GET /api/items` - List items
- `GET /api/items/<id>` - Get item details
- `GET /api/search?q=<query>` - Search items
- `GET /api/stats` - Platform statistics

---

## 📄 License

MIT License

---

**Made with ❤️ for a sustainable future 🌱**
