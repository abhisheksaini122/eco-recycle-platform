import os
from datetime import timedelta

basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or \
        'sqlite:///' + os.path.join(basedir, 'product_recycle.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    LANGUAGES = {
        'en': 'English',
        'hi': 'हिन्दी',
        'bn': 'বাংলা',
        'te': 'తెలుగు',
        'mr': 'मराठी',
        'ta': 'தமிழ்',
        'gu': 'ગુજરાતી',
        'ur': 'اُردُو',
        'kn': 'ಕನ್ನಡ',
        'ml': 'മലയാളം',
        'or': 'ଓଡ଼ିଆ',
        'pa': 'ਪੰਜਾਬੀ'
    }

    UPLOAD_FOLDER = os.path.join(basedir, 'app/static/uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    ITEMS_PER_PAGE = 12
    HUGGINGFACE_API_KEY = os.environ.get('HUGGINGFACE_API_KEY') or ''

class DevelopmentConfig(Config):
    DEBUG = True
    TESTING = False

class ProductionConfig(Config):
    DEBUG = False
    TESTING = False

config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'default': DevelopmentConfig
}
