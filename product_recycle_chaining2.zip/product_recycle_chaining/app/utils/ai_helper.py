import requests
from flask import current_app

def auto_tag_image(image_path):
    try:
        api_key = current_app.config.get('HUGGINGFACE_API_KEY')
        if not api_key:
            return []

        HF_API = "https://api-inference.huggingface.co/models/openai/clip-vit-base-patch32"
        headers = {"Authorization": f"Bearer {api_key}"}

        with open(image_path, "rb") as img:
            response = requests.post(HF_API, headers=headers, data=img.read())

        if response.status_code == 200:
            result = response.json()
            tags = [item.get('label', '') for item in result[:5] if 'label' in item]
            return tags
        else:
            return []
    except Exception as e:
        print(f"AI tagging error: {e}")
        return []

def get_smart_recommendations(user_id, category=None):
    from app.models import Item
    query = Item.query.filter_by(status='available')
    if category:
        query = query.filter_by(category=category)
    return query.order_by(Item.views.desc()).limit(10).all()
