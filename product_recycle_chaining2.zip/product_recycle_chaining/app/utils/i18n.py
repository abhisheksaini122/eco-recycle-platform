from flask import request
import json
import os

LANGUAGES = {
    'en': 'English', 'hi': 'हिन्दी', 'bn': 'বাংলা', 'te': 'తెలుగు',
    'mr': 'मराठी', 'ta': 'தமிழ்', 'gu': 'ગુજરાતી', 'ur': 'اُردُو',
    'kn': 'ಕನ್ನಡ', 'ml': 'മലയാളം', 'or': 'ଓଡ଼ିଆ', 'pa': 'ਪੰਜਾਬੀ'
}

I18N_PATH = os.path.join(os.path.dirname(__file__), 'lang')

def get_locale():
    return request.args.get('lang') or request.cookies.get('lang') or 'en'

def gettext(key, locale=None):
    locale = locale or get_locale()
    try:
        lang_file = os.path.join(I18N_PATH, f'{locale}.json')
        with open(lang_file, 'r', encoding='utf-8') as f:
            translations = json.load(f)
        return translations.get(key, key)
    except Exception:
        if locale != 'en':
            return gettext(key, 'en')
        return key

def available_languages():
    return LANGUAGES
