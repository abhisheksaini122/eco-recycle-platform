from flask import Blueprint, jsonify, request
from app.models import Item, User, Transaction

bp = Blueprint('api', __name__)

@bp.route('/items', methods=['GET'])
def get_items():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 12, type=int)

    items = Item.query.filter_by(status='available').order_by(Item.created_at.desc()).paginate(page=page, per_page=per_page, error_out=False)

    return jsonify({
        'items': [{'id': item.id, 'title': item.title, 'description': item.description, 'category': item.category, 'condition': item.condition, 'listing_type': item.listing_type, 'image_url': item.image_url, 'location': item.location, 'auto_tags': item.auto_tags, 'created_at': item.created_at.isoformat()} for item in items.items],
        'total': items.total, 'pages': items.pages, 'current_page': items.page
    })

@bp.route('/items/<int:item_id>', methods=['GET'])
def get_item(item_id):
    item = Item.query.get_or_404(item_id)
    return jsonify({'id': item.id, 'title': item.title, 'description': item.description, 'category': item.category, 'condition': item.condition, 'listing_type': item.listing_type, 'image_url': item.image_url, 'location': item.location, 'status': item.status, 'views': item.views, 'auto_tags': item.auto_tags, 'owner': {'id': item.owner.id, 'username': item.owner.username, 'eco_points': item.owner.eco_points}, 'created_at': item.created_at.isoformat()})

@bp.route('/search', methods=['GET'])
def search_items():
    query = request.args.get('q', '')
    category = request.args.get('category', '')

    items_query = Item.query.filter_by(status='available')

    if query:
        items_query = items_query.filter((Item.title.ilike(f'%{query}%')) | (Item.description.ilike(f'%{query}%')) | (Item.auto_tags.ilike(f'%{query}%')))

    if category:
        items_query = items_query.filter_by(category=category)

    items = items_query.limit(20).all()

    return jsonify({'results': [{'id': item.id, 'title': item.title, 'category': item.category, 'listing_type': item.listing_type, 'auto_tags': item.auto_tags} for item in items]})

@bp.route('/stats', methods=['GET'])
def get_stats():
    total_items = Item.query.count()
    total_users = User.query.count()
    completed_transactions = Transaction.query.filter_by(status='completed').count()
    return jsonify({'total_items': total_items, 'total_users': total_users, 'completed_transactions': completed_transactions})
