from datetime import datetime
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(UserMixin, db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    phone = db.Column(db.String(15))
    address = db.Column(db.Text)
    city = db.Column(db.String(100))
    state = db.Column(db.String(100))
    pincode = db.Column(db.String(10))
    profile_image = db.Column(db.String(255), default='default.jpg')
    preferred_language = db.Column(db.String(5), default='en')
    is_admin = db.Column(db.Boolean, default=False)
    is_verified = db.Column(db.Boolean, default=False)
    eco_points = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime)

    items = db.relationship('Item', backref='owner', lazy='dynamic', 
                           foreign_keys='Item.user_id')
    transactions_given = db.relationship('Transaction', backref='giver', lazy='dynamic',
                                        foreign_keys='Transaction.from_user_id')
    transactions_received = db.relationship('Transaction', backref='receiver', lazy='dynamic',
                                           foreign_keys='Transaction.to_user_id')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def add_eco_points(self, points):
        self.eco_points += points
        db.session.commit()

    def __repr__(self):
        return f'<User {self.username}>'

class Item(db.Model):
    __tablename__ = 'items'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(50), nullable=False)
    condition = db.Column(db.String(50))
    quantity = db.Column(db.Integer, default=1)
    listing_type = db.Column(db.String(20), nullable=False)
    exchange_preference = db.Column(db.String(200))
    image_url = db.Column(db.String(255))
    location = db.Column(db.String(200))
    status = db.Column(db.String(20), default='available')
    views = db.Column(db.Integer, default=0)
    is_featured = db.Column(db.Boolean, default=False)
    auto_tags = db.Column(db.String(250))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    transactions = db.relationship('Transaction', backref='item', lazy='dynamic')

    def increment_views(self):
        self.views += 1
        db.session.commit()

    def __repr__(self):
        return f'<Item {self.title}>'

class Transaction(db.Model):
    __tablename__ = 'transactions'

    id = db.Column(db.Integer, primary_key=True)
    item_id = db.Column(db.Integer, db.ForeignKey('items.id'), nullable=False)
    from_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    to_user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    status = db.Column(db.String(20), default='pending')
    request_message = db.Column(db.Text)
    response_message = db.Column(db.Text)
    rating = db.Column(db.Integer)
    feedback = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    completed_at = db.Column(db.DateTime)

    def approve(self):
        self.status = 'approved'
        db.session.commit()

    def reject(self, message=None):
        self.status = 'rejected'
        if message:
            self.response_message = message
        db.session.commit()

    def complete(self):
        self.status = 'completed'
        self.completed_at = datetime.utcnow()
        self.giver.add_eco_points(10)
        self.receiver.add_eco_points(5)
        self.item.status = 'completed'
        db.session.commit()

    def __repr__(self):
        return f'<Transaction {self.id}>'
